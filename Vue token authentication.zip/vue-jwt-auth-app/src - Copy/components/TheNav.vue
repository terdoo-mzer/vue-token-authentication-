<template>
    <nav>
        <RouterLink to="/">Home</RouterLink>
        <RouterLink to="/about">About</RouterLink>
      </nav>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>