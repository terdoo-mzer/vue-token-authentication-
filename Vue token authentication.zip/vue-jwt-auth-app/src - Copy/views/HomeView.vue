<script setup>
import TheWelcome from '../components/TheWelcome.vue'
import TheNav from '../components/TheNav.vue';
</script>

<template>
  <main>
    <!-- <TheNav /> -->
    <TheWelcome />
  </main>
</template>
