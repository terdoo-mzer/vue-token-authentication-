<template>
    <div>
        <h3>Login Page</h3>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>