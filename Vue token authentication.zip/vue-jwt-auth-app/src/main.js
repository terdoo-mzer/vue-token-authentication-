import './assets/main.css'
import store from './store/store'
import axios from 'axios'

// Vue.config.productionTip = false

import { createApp } from 'vue'
import App from './App.vue'
import router from './router/index.js'
// import { useStore } from "vuex";


// Create your app after
const app = createApp(App);

// const store = useStore();
app.use(store);
app.use(router)

// Load user from localstorage to state before rendering a component
const userData = localStorage.getItem('user')
if (userData) {
  store.commit('SET_USER_DATA', JSON.parse(userData))
}



app.mount('#app');

// Forcefully logout a user when they try to access a protected route without permission
axios.interceptors.response.use(
  response => response, // simply return the response 
  error => {
    if (error.response.status === 401 && userData) { // if we catch a 401 error
      store.dispatch('logout') // force a log out 
    }
    return Promise.reject(error) // reject the Promise, with the error as the reason
  }
)


