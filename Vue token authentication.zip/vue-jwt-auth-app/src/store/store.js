// store/index.js
import { createStore } from 'vuex';
import axios from 'axios';

export default createStore({
  state: {
    user: null
  },
  mutations: {
    SET_USER_DATA (state, data) {
      state.user = data
      localStorage.setItem('user', JSON.stringify(data))
      axios.defaults.headers.common['Authorization'] = `Bearer ${
        data.token
      }`
    },
    CLEAR_USER_DATA () {
      localStorage.removeItem('user')
      location.reload()
    }
  },
  actions: {
    setUserFromLocalStorage ({commit}, userData) {// This action will be used at the creation of vue app to reload state
      return new Promise((resolve) => {
        const userString = localStorage.getItem('user');

        if (!userString) {
          // You can resolve or reject here, depending on your use-case, but generally,
          // you want to resolve so that the app continues as usual, even without a user.
          return resolve();
        }

        commit('SET_USER_DATA', JSON.parse(userString));

        return resolve();
      });
    },
    register({commit}, credentials) {
      return axios.post('//localhost:3000/register',credentials)
      .then(({ data }) => {
        // console.log(data)
        commit('SET_USER_DATA', data)
      })
    },

    login({commit}, credentials) {
      return axios.post('//localhost:3000/login',credentials)
      .then(({ data }) => {
        // console.log(data)
        commit('SET_USER_DATA', data)
      })
    },
    logout ({ commit }) {
      commit('CLEAR_USER_DATA')
    }
  },
  getters: {
    loggedIn (state) {
      return !!state.user
    }
  }
});
