<template>
  <div>
    <AppNav />
    <RouterView class="page" />
  </div>
</template>

<script setup>
import { RouterView } from 'vue-router';
import AppNav from './components/AppNav.vue'

</script>

<style>

.page {
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  min-height: calc(100vh - 56px);
}
</style>
