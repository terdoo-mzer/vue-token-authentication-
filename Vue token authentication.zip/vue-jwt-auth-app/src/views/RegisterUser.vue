<template>
  <div>
    <form @submit.prevent="onRegister">
      <label for="name"> Name: </label>
      <input v-model="userRegistrationState.name" type="text" name="name" id="name" value />

      <label for="email"> Email: </label>
      <input v-model="userRegistrationState.email" type="email" name="email" id="email" value />

      <label for="password"> Password: </label>
      <input v-model="userRegistrationState.password" type="password" id="password" name value />

      <button type="submit" name="button">Register</button>
      <ul v-if="userRegistrationState.errors">
        <li v-for="(error, index) in userRegistrationState.errors" :key="error.index" :index="index">{{ error }}</li>
    </ul>
    </form>
    
    

    <div>
        <RouterLink to="/login">
            Have an account? Login Here
        </RouterLink>
    </div>
  </div>
</template>

  
<script setup>
import { useStore } from "vuex";
import { reactive, ref } from 'vue';
import { useRouter, useRoute } from 'vue-router'

const router = useRouter()
const route = useRoute()
const store = useStore();

// const name = ref('') 
// Use the above alternatively to get the Name value from the input field.
// The value can be accessed by doing console.log(name.value)

const userRegistrationState = reactive({
  name: "",
  email: "",
  password: "",
  errors: null
});

const onRegister = () => {
    // console.log(userRegistrationState)
    // return;
  store.dispatch("register", {
    name: userRegistrationState.name,
    email: userRegistrationState.email,
    password: userRegistrationState.password,
  })
  .then(() => {
    router.push({name: 'dashboard'})
  })
  .catch(err => {
    console.log(err)
    userRegistrationState.errors = err.response.data.errors
    console.log(userRegistrationState.errors)
  })

};
</script>

<style scoped>

</style>