<template>
  <div class="home">
    <h1>Welcome to the App!</h1>

    <div v-if="!loggedIn">
      To use this app you'll need to
      <router-link to="/login"> Login </router-link>
      or
      <router-link to="/register"> Register </router-link>
    </div>
  </div>
</template>

<script setup>
// import { authComputed } from "../store/helpers.js";
import { useStore } from 'vuex'
  import { computed } from 'vue'
  const store = useStore()

  const loggedIn  = computed(() => store.getters.loggedIn)

// export default {
//   computed: {
//     ...authComputed,
//   },
// };
</script>
