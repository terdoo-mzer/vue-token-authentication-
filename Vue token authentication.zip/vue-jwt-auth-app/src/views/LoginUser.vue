<template>
  <div>
    <form @submit.prevent="onLogin">
      <label for="email"> Email: </label>
      <input v-model="userLoginState.email" type="email" name="email" id="email" value  />

      <label for="password"> Password: </label>
      <input v-model="userLoginState.password" type="password" name="password" id="password" value />

      <button type="submit" name="button">Login</button>
      <p v-if="userLoginState.error"> {{ userLoginState.error }} </p>
    </form>
    
    <div>
      <RouterLink to="/register">
        Don't have an account? Register Here
      </RouterLink>
    </div>
  </div>
</template>
  
    
  <script setup>
import { useStore } from "vuex";
import { reactive, ref } from "vue";
import { useRouter, useRoute } from "vue-router";

const router = useRouter();
const route = useRoute();

const store = useStore();

// const name = ref('')
// Use the above alternatively to get the Name value from the input field.
// The value can be accessed by doing console.log(name.value)

const userLoginState = reactive({
  email: "",
  password: "",
  error: null
});

const onLogin = () => {
  store
    .dispatch("login", {
      email: userLoginState.email,
      password: userLoginState.password,
    })
    .then(() => {
      router.push({ name: "dashboard" });
    })
    .catch((err) => {
        console.log(err)
      userLoginState.error = err.response.data.error;
    });
};
</script>
