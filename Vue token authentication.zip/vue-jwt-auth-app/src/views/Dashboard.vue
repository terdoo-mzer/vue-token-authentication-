<template>
  <div>
    <h1>Dashboard</h1>
    <template v-if="!isLoading">
      <EventCard v-for="event in events" :key="event.id" :event="event" />
    </template>
    <p v-else>Loading events</p>
  </div>
</template>

<script setup>
import axios from "axios";
import EventCard from "../components/EventCard.vue";
import { onMounted, ref, onBeforeMount } from "vue";
import { useStore } from "vuex";

const store = useStore();
const events = ref([]);
const isLoading = ref(true);

onMounted(() => {
  const userString = localStorage.getItem("user"); // grab user data from local storage
  if (userString) {
    // check to see if there is indeed a user
    const userData = JSON.parse(userString); // parse user data into JSON
    store.commit("SET_USER_DATA", userData); // restore user data with Vuex
  }
  axios
    .get("//localhost:3000/dashboard")
    .then(({ data }) => {
      console.log(data);
      events.value = data.events.events;
      isLoading.value = false;
    })
    .catch((err) => {
      console.log(err);
    });
});
</script>
