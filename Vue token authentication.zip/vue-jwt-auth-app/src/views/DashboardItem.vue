<template>
    <div>
        <p>Items</p>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>